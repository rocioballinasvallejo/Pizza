package com.upchiapas.quem.model;

public class CatalogoPizza extends Pizza {
    public CatalogoPizza(){
    }
    public CatalogoPizza(short id, String especialidad, float precio){
        super(id, especialidad,precio);
    }
}
