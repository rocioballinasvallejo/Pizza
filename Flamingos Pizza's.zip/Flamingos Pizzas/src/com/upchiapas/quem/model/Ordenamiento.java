package com.upchiapas.quem.model;

public class Ordenamiento {

			String vecDatos[] = new String[30];
    		class Node{
    					String data;
        				Node next;
        	public Node(String data)
        		{
        				this.data = data;
        				this.next = null;}
    			}
    		public Node head = null;
    		public Node tail = null;
    		public void addNode(String data)
    			{
    					Node newNode = new Node(data);
        	if (head == null) {
            			head = newNode;
            			tail = newNode;}
        	else{
            			tail.next = newNode;
            			tail = newNode;}
    			}
    		public void sortList()
    			{
    					Node current = head, index = null;

        				String temp;

        				if (head == null) {
            return;}
        	else{
        				while (current != null) {
            			index = current.next;
            			while (index != null)
                {
            if(current.data.compareTo(index.data)>0){
                        temp = current.data;
                        current.data = index.data;
                        index.data = temp;}
                    	index = index.next;}
                		current = current.next;}
        		}
    			}
    					public void display(){
    					int x=0;
    					Node current = head;

    					if (head == null){
    					System.out.println("List is empty");
    					return;
    			}
    		while (current != null) {
    					x++;
    					vecDatos[x]=current.data;
    					current = current.next;}
    			}
    		public String darValor(int i) {
    					String darValor;
    					darValor=vecDatos[i];
    					return darValor;}
				}


