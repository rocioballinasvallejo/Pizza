package com.upchiapas.quem;
import com.upchiapas.quem.model.*;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {
    public static CatalogoPizza entry = new CatalogoPizza();

    public static OrdenCompra ordenentry = new OrdenCompra();
    public static Queue<ItemCompra> vecHistory = new LinkedList<ItemCompra>();
    public static Queue<CatalogoPizza> vecCatalogo = new LinkedList<CatalogoPizza>();
    public static Queue<OrdenCompra> vecOrden = new LinkedList<OrdenCompra>();
    public static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args){
        int estado=0;
        do{
            estado=Inicio(estado);
        }while(estado!=2);
    }
    public static int Inicio(int estado){
        int i=0;
        do{
        	System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
            System.out.println ("Flamingos Pizza’s");
            System.out.println ("1. integrar a el Catálogo");
            System.out.println ("2. Orden de la compra de la pizza)|");
            System.out.println ("3. Registro De la pizzeria");
            System.out.println ("4. Salir");
            System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
            switch (teclado.nextInt()){
                case 1:{
                	do{
                		System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
                        System.out.println("agregar codigo de 4 digitos de la Pizza");
                        entry.setId(teclado.nextShort());
                        System.out.println("Especialida de la Pizza");
                        entry.setEspecialidad(teclado.nextLine());
                        entry.setEspecialidad(teclado.nextLine());
                        System.out.println("agregar el precio de la pizza");
                        entry.setPrecio(teclado.nextFloat());
                        vecCatalogo.add(new CatalogoPizza(entry.getId(),entry.getEspecialidad(),entry.getPrecio()));
                        System.out.println("agregar otra pizza ?");
                        System.out.println("1. si 2. No");
                        System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
                        i=teclado.nextInt();
                    }while(i!=2);
                }break;
                case 2:{
                    OrdenPizza();
                }break;
                case 3:{
                    ReporteTiend();
                }break;
                case 4:{
                    estado=2;
                }break;
            }
        }while(estado!=2);
        return estado;
    }

    public static void OrdenPizza(){
        short id_compra = 0;
        float subSuma=0;
        do{
            MostrarCatalogo();
            System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
            System.out.println("codigo de 4 digitos de la pizza para pedir");
            id_compra=teclado.nextShort();
            for (CatalogoPizza entra :vecCatalogo) {
                if(entra.getId()==id_compra){
                    System.out.println("Cantidad");
                    ordenentry.setCantidad(teclado.nextByte());
                    subSuma=subSuma+entra.getPrecio()*ordenentry.getCantidad();
                    ordenentry.setSubtotal(subSuma);
                    vecOrden.add(new OrdenCompra(ordenentry.getCantidad(),ordenentry.getSubtotal(),entra.getId(),entra.getEspecialidad(),entra.getPrecio()));
                    vecHistory.add(new ItemCompra(ordenentry.getCantidad(),ordenentry.getSubtotal(),entra.getId(),entra.getEspecialidad(),entra.getPrecio()));
                }
            }
            System.out.println("Cerar pedido");
            System.out.println("1. Si  2. No");
            System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
        }while (teclado.nextInt()!=2);
        MostrarOrden();
    }
    public static void ReporteTiend(){
        int i=1;
        String mostrar1;
        System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
        System.out.println("Registro de venta");
        Ordenamiento sList = new Ordenamiento ();
        for(ItemCompra date : vecHistory){
            sList.addNode(date.getEspecialidad());}
        sList.display();
        sList.sortList();
        sList.display();
        for (ItemCompra var : vecHistory){
            mostrar1=sList.darValor(i);
            for(ItemCompra repor : vecHistory){
                if (repor.getEspecialidad().equals(mostrar1)){
                    System.out.println(repor.toString()+"\n");}
            }
            i++;
        }
        System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
    }
    public static void MostrarCatalogo(){
        int i=1;
        System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
        System.out.println("Catalogo");
        String mostrar1;
        Ordenamiento sList = new Ordenamiento ();
        for(CatalogoPizza entra1 : vecCatalogo){
            sList.addNode(entra1.getEspecialidad());
        }
        sList.display();
        // Sorting list
        sList.sortList();
        // Displaying sorted list
        sList.display();
        for (CatalogoPizza var : vecCatalogo){
            mostrar1=sList.darValor(i);
            for(CatalogoPizza ordenar : vecCatalogo){
                if (ordenar.getEspecialidad().equals(mostrar1)){
                    System.out.println(ordenar.toString());
                }
            }
            i++;
        }
        System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
    }
    public static void MostrarOrden(){
        int X=1;
        String mostrar;
        System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
        System.out.println("Nota o Ticket de compra");
        Ordenamiento sList = new Ordenamiento ();
        for(OrdenCompra entra1 : vecOrden){
            sList.addNode(entra1.getEspecialidad());
        }
        sList.display();
        sList.sortList();
        sList.display();
        for(OrdenCompra var : vecOrden){
            mostrar=sList.darValor(X);
            for(OrdenCompra ordenar : vecOrden){
                if (ordenar.getEspecialidad().equals(mostrar)){
                    System.out.println(ordenar.toString());
                }
            }
            X++;}
        System.out.println ("♡▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒♡");
        borrarDatos();
    }
    public static void borrarDatos(){
        int i=0;
        for (OrdenCompra estadoOrden: vecOrden){
            if(estadoOrden.getEspecialidad()!=null) {
                vecOrden.remove();
                i++;
            }
        }
    }

}
